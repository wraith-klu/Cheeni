@echo off
REM ============================================================
REM  Cheeni Desktop Agent — Master Launcher
REM  Starts all 3 services silently and opens the UI
REM ============================================================

REM Get the directory where this script lives
set "CHEENI_DIR=%~dp0"

REM ── 1. Start Python Desktop Agent (port 2026) ──────────────
echo [Cheeni] Starting Python Desktop Agent...
start /B /MIN "" cmd /c "cd /d "%CHEENI_DIR%cheeni-agent" && python main.py"

REM ── 2. Start Node.js Backend (port 2025) ────────────────────
echo [Cheeni] Starting Node.js Backend...
start /B /MIN "" cmd /c "cd /d "%CHEENI_DIR%backend" && node index.js"

REM ── 3. Wait for services to initialize ──────────────────────
echo [Cheeni] Waiting for services to initialize...
timeout /t 4 /nobreak >nul

REM ── 4. Start Frontend Dev Server (port 5173) ────────────────
echo [Cheeni] Starting Frontend Dev Server...
start /B /MIN "" cmd /c "cd /d "%CHEENI_DIR%frontend" && npm run dev"

REM ── 5. Wait for Vite to be ready ────────────────────────────
timeout /t 3 /nobreak >nul

REM ── 6. Open Cheeni in Chrome/Edge App Mode (fullscreen) ─────
echo [Cheeni] Opening Cheeni Landing Page...

REM Try Chrome first
where chrome >nul 2>&1
if %ERRORLEVEL%==0 (
    start "" chrome --app=http://localhost:5173 --start-maximized --disable-infobars --no-first-run --autoplay-policy=no-user-gesture-required
    goto :done
)

REM Try Chrome from common install paths
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app=http://localhost:5173 --start-maximized --disable-infobars --no-first-run --autoplay-policy=no-user-gesture-required
    goto :done
)

if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --app=http://localhost:5173 --start-maximized --disable-infobars --no-first-run --autoplay-policy=no-user-gesture-required
    goto :done
)

REM Fallback to Microsoft Edge (always available on Windows 10/11)
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:5173 --start-maximized --disable-infobars --no-first-run --autoplay-policy=no-user-gesture-required
    goto :done
)

REM Last resort: default browser
start http://localhost:5173

:done
echo [Cheeni] All services launched! Cheeni is ready.
