============================================================
  Cheeni AI Desktop Agent -- 1-Click Windows Setup
============================================================

Thank you for downloading Cheeni AI Desktop Agent!

QUICK START INSTRUCTIONS:
1. Extract all files from this ZIP to your Cheeni project directory
   (or keep them together in your Cheeni folder).
2. Double-click "install_autostart.bat" (or right-click and run as Administrator).
3. That's it! Cheeni is now registered in your Windows Startup.

WHENEVER YOU OPEN YOUR LAPTOP:
- Windows will automatically awaken Cheeni in the background silently.
- The Python desktop agent, backend server, and Agent Home Page will launch.
- Cheeni will be ready immediately for voice commands, window management,
  app launching, web search, and filesystem control!

TO UNINSTALL AUTO-START:
- Run "uninstall_autostart.bat" anytime to remove the startup shortcut.

SYSTEM REQUIREMENTS:
- Windows 10 or Windows 11 (64-bit)
- Python 3.10+ (for Python agent tools)
- Node.js 18+
- Google Chrome or Microsoft Edge
============================================================
